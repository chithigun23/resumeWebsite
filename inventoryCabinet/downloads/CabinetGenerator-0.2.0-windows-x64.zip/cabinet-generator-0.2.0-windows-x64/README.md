# CabinetGenerator

A desktop app (Linux and Windows) that builds the printable parts of the modular pull-out-tub cabinet from a config file:
the cabinet module, back panel, drawers, joining brackets, controller clamp tabs and the row punch that opens the LED and Hall
windows. It previews them in 3D, packs them onto
plates for your printer's bed, and exports a print pack (oriented STLs, plates, a print guide and a manifest).

It replaces the Python/CadQuery generator for this job. The geometry is a Rust port of `cad/cabinet.py` on the Manifold
CSG kernel, checked against the Python output (see Tests). Building all six parts takes about 0.1 s, so the preview updates as
you drag a slider.

The website's **Print Planner and Config** section is the demo: it plans sizes and plates for any module size and saves the
config file this app opens. The website makes no STL files.

## Install

Downloads (built by `scripts/package.sh` into `dist/`, and listed on the website):

| For | File | Install |
|---|---|---|
| Windows 10 or 11 | `CabinetGenerator-<v>-Setup-x64.exe` | Run it. Installs for your account only (no administrator rights), adds a Start menu shortcut, an Apps & features entry and an uninstaller. `/S` installs silently (`/DESKTOP` adds a desktop shortcut, `/D=<folder>` picks the folder). |
| Windows, portable | `CabinetGenerator-<v>-windows-x64.zip` | Unzip and run `cabinet-generator.exe`. |
| Debian, Ubuntu | `cabinet-generator_<v>_amd64.deb` | `sudo apt install ./cabinet-generator_<v>_amd64.deb` |
| Any Linux | `CabinetGenerator-<v>-x86_64.AppImage` | `chmod +x` it and run it. |
| Any Linux | `cabinet-generator-<v>-linux-x86_64.tar.gz` | Unpack, run `./install.sh` (to `~/.local`, no root); `./uninstall.sh` removes it. |

The Windows files are not code-signed, so SmartScreen may warn ("More info", "Run anyway"). Each package carries the app icon, a
desktop entry (`com.chithigunatilake.CabinetGenerator`), AppStream metadata, the licence and the third-party licence list.
`scripts/deploy-website.sh` copies `dist/` to the website's `inventoryCabinet/downloads` folder.

## Run

```
cabinet-generator                       # start with the default 3x2 cabinet
cabinet-generator my-config.json        # open a config (or drag the file onto the window)
cabinet-generator --pos 3700,60         # window position (logical pixels), e.g. to open on a second screen
cabinet-generator --view plates         # start in the Plates view (assembly | part | plates; --part tub for the Part view)
```

Left-drag orbits, right-drag pans, scroll zooms. The three tabs:

- **Assembly**: the cabinet, with drawers you can pull out.
- **Part**: one part, in model or print orientation.
- **Plates**: the plates for your printer, one at a time, on the bed.

File menu: open and save configs, export the print pack (zip or folder), export one part, one plate, or the hole-tolerance test
coupon as STL. Needs OpenGL 3.1 or newer.

## Headless

```
cabinet-generator-cli default-config > my.json
cabinet-generator-cli info my.json
cabinet-generator-cli generate my.json --out ./pack --zip [--scope assembly|module|drawer]
```

## Config file

JSON written by the website or the app. Every field is optional (defaults are the standard module); unknown fields are an error.

```json
{
  "format": "ims-cabinet-config",
  "version": 1,
  "name": "",
  "module":   { "module_cols": 5, "module_rows": 5, "cell_w": 41.4, "cell_h": 28.0, "depth": 90.0,
                "wall": 2.4, "shelf": 4.0, "clearance": 0.5, "travel": 45.0 },
  "assembly": { "modules_across": 3, "modules_high": 2 },
  "printer":  { "bed_width": 256.0, "bed_depth": 256.0, "spacing": 4.0 }
}
```

The `module` object takes the nine fields above (their ranges are in `crates/core/src/params.rs`, `LIMITS`) and, in the app's
"All parameters" list, every other generator parameter (walls, handle, bay, cable and screw dimensions) for reproducing a design.

## Build

```
cargo build --release              # target/release/cabinet-generator and cabinet-generator-cli
cargo test --release -p cabinet-core
scripts/package.sh                 # every download in dist/ (see Install); skips what the machine lacks tools for
```

Needs Rust 1.95 or newer and CMake plus a C++ compiler (the Manifold library is built from source, about a minute). On Linux
no GUI development packages are needed. The first build downloads crates.

Windows: `.github/workflows/app.yml` builds and tests natively on Windows and Linux in CI. From Linux,
`scripts/build-windows.sh` cross-compiles both Windows executables with Zig (`pip install ziglang`,
`cargo install cargo-zigbuild`, `rustup target add x86_64-pc-windows-gnu`). They import only system DLLs.
**The Windows build has not been run on a Windows machine.**

## Tests

`cargo test --release -p cabinet-core` checks that:

- the six parts match the Python generator's STL files for the default size and for four custom sizes (module, back panel,
  drawer, bracket, clamp tab, row punch: shapes differ by under 0.1% of volume, bounding boxes within 0.02 mm), and the small
  features that whole-part numbers hide (rounded oversize windows, the window skin, the groove chamfer, the punch pins, end tab
  and handle) differ by under 0.25 mm3 inside small boxes around them;
- the row punch goes through the punched module without touching it and overlaps the printed skin it shears;
- the quantities equal the Python BOM's for every assembly from 1x1 to 10x10 modules;
- the website's part-size formulas equal the real geometry across the parameter ranges;
- the default 3x2 pack is 28 plate prints, small beds skip parts that do not fit, and configs round-trip and reject bad input.

The reference STLs for the custom sizes are in `crates/core/tests/data`; the default-size ones are read from
`cad/out/full` when it exists. `scripts/gen_reference_stls.py` regenerates the custom-size ones (with the row punch).

## Layout

- `crates/core`: `params` (config), `geom` and `parts` (the geometry), `mesh` (STL, orientation), `plan` (counts, packing),
  `export` (print pack).
- `crates/cli`: `cabinet-generator-cli`. `crates/app`: `cabinet-generator` (egui with an OpenGL 3D view).
- `crates/installer`: the Windows setup program (carries the app files; also the uninstaller). Built by `scripts/package.sh`.
- `assets/`: the icon (`scripts/make_icons.py` draws the SVG, PNGs and ICO). `packaging/`: Windows manifest, Linux desktop entry and metadata.

## Not included

The BOM costs, PCB lists, CAD verification checks and the full 3D assembly (strips, controller, cables, screws) stay in the
Python generator and the website viewer. Nothing here changes the KiCad projects.
