#!/bin/sh
# Install CabinetGenerator for the current user (no root): programs in ~/.local/bin, launcher and icons under ~/.local/share.
set -e
here=$(cd "$(dirname "$0")" && pwd)
prefix=${PREFIX:-$HOME/.local}
id=com.chithigunatilake.CabinetGenerator
install -d "$prefix/bin" "$prefix/share/applications" "$prefix/share/metainfo" "$prefix/share/icons/hicolor/scalable/apps"
install -m 755 "$here/cabinet-generator" "$here/cabinet-generator-cli" "$prefix/bin/"
install -m 644 "$here/$id.desktop" "$prefix/share/applications/"
install -m 644 "$here/$id.metainfo.xml" "$prefix/share/metainfo/"
install -m 644 "$here/icons/icon.svg" "$prefix/share/icons/hicolor/scalable/apps/$id.svg"
for n in 16 32 48 64 128 256 512; do
  install -d "$prefix/share/icons/hicolor/${n}x${n}/apps"
  install -m 644 "$here/icons/icon-$n.png" "$prefix/share/icons/hicolor/${n}x${n}/apps/$id.png"
done
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$prefix/share/applications" || true
command -v gtk-update-icon-cache >/dev/null 2>&1 && gtk-update-icon-cache -q -t "$prefix/share/icons/hicolor" || true
echo "Installed to $prefix. Start it from the applications menu or run: cabinet-generator"
case ":$PATH:" in *":$prefix/bin:"*) ;; *) echo "Note: $prefix/bin is not on your PATH." ;; esac
