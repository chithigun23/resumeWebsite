#!/bin/sh
# Remove what install.sh put in place.
prefix=${PREFIX:-$HOME/.local}
id=com.chithigunatilake.CabinetGenerator
rm -f "$prefix/bin/cabinet-generator" "$prefix/bin/cabinet-generator-cli" "$prefix/share/applications/$id.desktop" "$prefix/share/metainfo/$id.metainfo.xml" \
      "$prefix/share/icons/hicolor/scalable/apps/$id.svg"
for n in 16 32 48 64 128 256 512; do rm -f "$prefix/share/icons/hicolor/${n}x${n}/apps/$id.png"; done
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$prefix/share/applications" || true
echo "Removed."
